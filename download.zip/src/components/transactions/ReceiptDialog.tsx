// src/components/transactions/ReceiptDialog.tsx
// This file is no longer used as receipts are displayed on a dedicated page.
// It can be safely deleted.
// Keeping it empty for now to signify it's been addressed.
