// src/app/page.tsx
import AuthRedirectClient from '@/components/core/AuthRedirectClient';

export default function HomePage() {
  return <AuthRedirectClient />;
}
